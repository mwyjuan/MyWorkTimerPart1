import 'package:flutter/material.dart';
import 'widget.dart';

void main() => runApp(MyApp());


class MyApp extends StatelessWidget {

  final double defaultpadding = 5.0;
  @override
  Widget build(BuildContext) {
    return MaterialApp(
      title: 'My Work Timer',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
      ),
      home: TimerHomePage(),
    );
  }
}

class TimerHomePage extends StatelessWidget {
  final double defaultPadding = 5.0;
  @override
  Widget build(BuildContext){
    return Scaffold(
        appBar: AppBar(
          title: Text('My Work Timer'),
        ),
        body: Column (
            children: [
              Row(
                children:[
                  SizedBox(height:20),
              Padding(padding:EdgeInsets.all(defaultPadding)),
              Expanded(child: ProductivityButton(
                color:Color(0xff009688),
                text:"Work",
                onPressed: emptyMethod,
                size: 150)), //ProduvtivityButton, Expanded
               Padding(padding:EdgeInsets.all(defaultPadding)),
              Expanded(child: ProductivityButton(
                color:Color(0xff009688),
                text:"Work",
                onPressed: emptyMethod,
                size: 150)), //ProduvtivityButton, Expanded Padding(padding:EdgeInsets.all(defaultPadding)),
              Expanded(child: ProductivityButton(
                color:Color(0xff009688),
                text:"Work",
                onPressed: emptyMethod,
                size: 150)), //ProduvtivityButton, Expanded

            ],
          ),
           Expanded(child: Center(
            child: Text(
              "Hello new app",
              style: TextStyle(fontSize: 24),
            ),
           ),
           ),
           Row(
                children:[
                  SizedBox(height:20),
              Padding(padding:EdgeInsets.all(defaultPadding)),
              Expanded(child: ProductivityButton(
                color:Color(0xff009688),
                text:"Stop",
                onPressed: emptyMethod,
                size: 150)), //ProduvtivityButton, Expanded
               Padding(padding:EdgeInsets.all(defaultPadding)),
              Expanded(child: ProductivityButton(
                color:Color(0xff009688),
                text:"Restart",
                onPressed: emptyMethod,
                size: 150)),

            ],
          ),
        ],
      ),
    );
  }
}

void emptyMethod(){

}